export const firebaseConfig = {
  apiKey: "AIzaSyAOGZxXOi0PLq7QIqxczPCgy3V5BaYOGzo",
  authDomain: "futebol-55e0a.firebaseapp.com",
  databaseURL: "https://futebol-55e0a-default-rtdb.firebaseio.com",
  projectId: "futebol-55e0a",
  storageBucket: "futebol-55e0a.appspot.com",
  messagingSenderId: "311124504663",
  appId: "1:311124504663:web:c69e0f79f57359e1023312"
};